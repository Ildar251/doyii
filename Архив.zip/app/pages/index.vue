<template>
	<div class="page">
		<SectionHero />
		<SectionServices :pageSize="8" />
		<SectionProjects />
		<SectionAbout />
		<SectionAdvantages />
		<SectionClients />
		<SectionTeam />
		<SectionForm />
		<SectionReviews />
		<SectionContacts />
	</div>
</template>

<script lang="ts" setup></script>
