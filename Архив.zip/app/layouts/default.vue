<template>
	<Header />
	<main>
		<slot />
	</main>
	<Footer />
	<ModalForm />
</template>
