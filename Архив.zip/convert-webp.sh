#!/usr/bin/env bash

# Настройки (можно переопределять переменными окружения при запуске):
ROOT_DIR="${ROOT_DIR:-"$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/app/assets"}"
CWEBP_BIN="${CWEBP_BIN:-cwebp}"   # путь к cwebp, если не в PATH — укажи полный
QUALITY="${QUALITY:-100}"         # качество WebP: 1..100
DELETE_ORIGINALS="${DELETE_ORIGINALS:-1}"  # 1 = удалять исходники, 0 = оставить
OVERWRITE="${OVERWRITE:-0}"       # 1 = перезаписывать .webp если уже есть

if ! command -v "$CWEBP_BIN" >/dev/null 2>&1; then
  echo "❌ Не найден cwebp. Установи: brew install webp"
  exit 1
fi

echo "Поиск изображений в: $ROOT_DIR"
echo "-----------------------------"

# Собираем список файлов с нужными расширениями и бережно обрабатываем пробелы
find "$ROOT_DIR" -type f \( \
  -iname "*.jpg"  -o -iname "*.jpeg" -o -iname "*.png"  -o -iname "*.bmp" \
  -iname "*.tif"  -o -iname "*.tiff" -o -iname "*.gif"  -o -iname "*.heic" \
  -o -iname "*.avif" \
\) -print0 | while IFS= read -r -d '' INPUT; do
  # Определяем расширение в нижнем регистре
  ext="$(echo "${INPUT##*.}" | tr '[:upper:]' '[:lower:]')"
  OUTPUT="${INPUT%.*}.webp"

  if [[ "$OVERWRITE" != "1" && -e "$OUTPUT" ]]; then
    echo "⚠️  Уже есть .webp, пропускаю: $OUTPUT"
    continue
  fi

  convert_ok=0

  case "$ext" in
    gif)
      # Для GIF — gif2webp (сохраняет анимацию)
      if command -v gif2webp >/dev/null 2>&1; then
        gif2webp -q "$QUALITY" "$INPUT" -o "$OUTPUT" >/dev/null 2>&1 && convert_ok=1
      else
        # fallback: статическое преобразование (первый кадр)
        "$CWEBP_BIN" -q "$QUALITY" "$INPUT" -o "$OUTPUT" >/dev/null 2>&1 && convert_ok=1
      fi
      ;;
    heic|avif)
      # Через ImageMagick -> PNG -> WebP (для HEIC/AVIF)
      if command -v magick >/dev/null 2>&1; then
        TMP_png="$(mktemp -t img2webp.XXXXXX).png"
        if magick "$INPUT" -auto-orient "$TMP_png" >/dev/null 2>&1; then
          "$CWEBP_BIN" -q "$QUALITY" "$TMP_png" -o "$OUTPUT" >/dev/null 2>&1 && convert_ok=1
        fi
        rm -f "$TMP_png"
      elif [[ "$ext" == "heic" ]] && command -v sips >/dev/null 2>&1; then
        # HEIC можно через встроенный sips (AVIF — нет)
        TMP_png="$(mktemp -t img2webp.XXXXXX).png"
        if sips -s format png "$INPUT" --out "$TMP_png" >/dev/null 2>&1; then
          "$CWEBP_BIN" -q "$QUALITY" "$TMP_png" -o "$OUTPUT" >/dev/null 2>&1 && convert_ok=1
        fi
        rm -f "$TMP_png"
      else
        echo "❌ Пропускаю (нет поддержки HEIC/AVIF): $INPUT"
      fi
      ;;
    *)
      "$CWEBP_BIN" -q "$QUALITY" "$INPUT" -o "$OUTPUT" >/dev/null 2>&1 && convert_ok=1
      ;;
  esac

  if [[ "$convert_ok" -eq 1 && -s "$OUTPUT" ]]; then
    echo "✅ Converted: $INPUT → $OUTPUT"
    if [[ "$DELETE_ORIGINALS" == "1" ]]; then rm -f "$INPUT"; fi
  else
    echo "❌ Failed to convert: $INPUT"
    [[ -f "$OUTPUT" ]] && rm -f "$OUTPUT"
  fi
done

echo "-----------------------------"
echo "✅ Все изображения обработаны."
